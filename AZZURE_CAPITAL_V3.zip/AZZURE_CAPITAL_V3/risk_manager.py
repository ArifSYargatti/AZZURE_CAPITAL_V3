
"""
risk_manager.py

AZZURE CAPITAL V3
Professional Risk Management Engine
"""

from config import (
    CAPITAL,
    RISK_PER_TRADE,
    MAX_OPEN_POSITIONS,
    MAX_TRADES_PER_DAY,
    MAX_CONSECUTIVE_LOSSES,
    DAILY_LOSS_LIMIT
)


class RiskManager:

    def __init__(self):

        self.total_pnl = 0.0

        self.trade_count = 0

        self.consecutive_losses = 0

    def calculate_quantity(
        self,
        entry_price,
        stop_loss
    ):

        risk_amount = CAPITAL * RISK_PER_TRADE

        risk_per_share = abs(entry_price - stop_loss)

        if risk_per_share <= 0:

            return 0

        qty = int(risk_amount / risk_per_share)

        return max(qty, 1)

    def can_take_trade(
        self,
        open_positions
    ):

        if self.total_pnl <= DAILY_LOSS_LIMIT:

            print("RISK CHECK : Daily loss limit reached")

            return False

        if open_positions >= MAX_OPEN_POSITIONS:

            print("RISK CHECK : Maximum open positions reached")

            return False

        if self.trade_count >= MAX_TRADES_PER_DAY:

            print("RISK CHECK : Maximum trades reached")

            return False

        if self.consecutive_losses >= MAX_CONSECUTIVE_LOSSES:

            print("RISK CHECK : Consecutive loss limit reached")

            return False

        return True

    def update_trade_result(
        self,
        pnl
    ):

        self.total_pnl += pnl

        self.trade_count += 1

        if pnl > 0:

            self.consecutive_losses = 0

        else:

            self.consecutive_losses += 1

    def get_summary(self):

        return {

            "total_pnl": self.total_pnl,

            "trade_count": self.trade_count,

            "consecutive_losses": self.consecutive_losses

        }

    def print_summary(self):

        print("=" * 50)

        print("RISK MANAGER")

        print(f"Total PnL           : {self.total_pnl}")

        print(f"Trades              : {self.trade_count}")

        print(f"Consecutive Losses  : {self.consecutive_losses}")

        print("=" * 50)

