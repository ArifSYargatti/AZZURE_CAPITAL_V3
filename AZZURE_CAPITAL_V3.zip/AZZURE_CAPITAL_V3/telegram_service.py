
"""
telegram_service.py

AZZURE CAPITAL V3
Telegram Notification Service
"""

import requests

from config import BOT_TOKEN, CHAT_ID


class TelegramService:

    def __init__(self):

        self.url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"

    def send_message(self, message):

        if BOT_TOKEN == "" or CHAT_ID == "":

            print("Telegram not configured")

            return False

        payload = {

            "chat_id": CHAT_ID,

            "text": message,

            "parse_mode": "Markdown"

        }

        try:

            response = requests.post(

                self.url,

                json=payload,

                timeout=10

            )

            if response.status_code == 200:

                print("Telegram message sent")

                return True

            else:

                print(f"Telegram Error : {response.text}")

                return False

        except Exception as e:

            print(f"Telegram Exception : {e}")

            return False

    def engine_started(self):

        self.send_message(
            "🚀 *AZZURE CAPITAL V3*\n\nTrading Engine Started."
        )

    def login_success(self, user):

        self.send_message(
            f"✅ Broker Login Successful\n\nUser : {user}"
        )

    def buy_signal(self, symbol, price):

        self.send_message(
            f"🟢 BUY SIGNAL\n\n"
            f"Stock : {symbol}\n"
            f"Entry : ₹{price}"
        )

    def target_hit(self, symbol, pnl):

        self.send_message(
            f"🎯 TARGET HIT\n\n"
            f"Stock : {symbol}\n"
            f"PnL : ₹{pnl}"
        )

    def stoploss_hit(self, symbol, pnl):

        self.send_message(
            f"🛑 STOP LOSS HIT\n\n"
            f"Stock : {symbol}\n"
            f"PnL : ₹{pnl}"
        )

    def trailing_exit(self, symbol, pnl):

        self.send_message(
            f"📈 TRAILING EXIT\n\n"
            f"Stock : {symbol}\n"
            f"PnL : ₹{pnl}"
        )

    def squareoff(self):

        self.send_message(
            "⏰ Auto Square-off Executed."
        )

    def daily_summary(

        self,

        trades,

        wins,

        losses,

        pnl

    ):

        self.send_message(

            f"📊 *Daily Summary*\n\n"

            f"Trades : {trades}\n"

            f"Wins : {wins}\n"

            f"Losses : {losses}\n"

            f"Net PnL : ₹{pnl}"

        )

    def error(self, text):

        self.send_message(

            f"⚠️ ENGINE ERROR\n\n{text}"

        )
