
"""
data_loader.py

Historical Data Loader for AZZURE CAPITAL V3
"""

import datetime
import pandas as pd


class DataLoader:

    def __init__(self, kite):

        self.kite = kite

    def get_data(
        self,
        instrument_token,
        interval="5minute",
        days=10
    ):

        try:

            from_date = (
                datetime.datetime.now()
                - datetime.timedelta(days=days)
            )

            to_date = datetime.datetime.now()

            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval=interval
            )

            df = pd.DataFrame(data)

            print(
                f"Loaded {len(df)} candles "
                f"({interval})"
            )

            return df

        except Exception as e:

            print(
                f"DATA LOAD ERROR : {e}"
            )

            return pd.DataFrame()

    def get_nifty_data(
        self,
        nifty_token
    ):

        return self.get_data(
            nifty_token,
            "5minute",
            10
        )

    def get_stock_5m(
        self,
        token
    ):

        return self.get_data(
            token,
            "5minute",
            10
        )

    def get_stock_15m(
        self,
        token
    ):

        return self.get_data(
            token,
            "15minute",
            10
        )

