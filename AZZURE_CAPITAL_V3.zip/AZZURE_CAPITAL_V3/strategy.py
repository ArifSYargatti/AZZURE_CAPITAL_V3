
"""
strategy.py

AZZURE CAPITAL V3
Professional Strategy Engine
"""


class Strategy:

    def __init__(self):

        self.signal_count = 0

    def check_entry(

        self,

        symbol,

        nifty_price,

        nifty_ema,

        live_price,

        ema5,

        ema15,

        stock_change,

        nifty_change,

        position_open

    ):

        result = {

            "signal": False,

            "reason": "",

            "score": 0,

            "nifty_bullish": False,

            "trend_confirmed": False,

            "relative_strength": False

        }

        # Position already open
        if position_open:

            result["reason"] = "Position already open"

            return result

        # NIFTY Filter
        if nifty_price > nifty_ema:

            result["nifty_bullish"] = True

            result["score"] += 1

        # Trend Filter
        if live_price > ema5 and live_price > ema15:

            result["trend_confirmed"] = True

            result["score"] += 1

        # Relative Strength
        if stock_change > nifty_change:

            result["relative_strength"] = True

            result["score"] += 1

        # Diagnostics
        print(
            f"{symbol} | "
            f"NIFTY={result['nifty_bullish']} | "
            f"TREND={result['trend_confirmed']} | "
            f"RS={result['relative_strength']} | "
            f"SCORE={result['score']}"
        )

        # Final Decision
        if result["score"] == 3:

            result["signal"] = True

            result["reason"] = "All conditions satisfied"

            self.signal_count += 1

        elif result["score"] == 2:

            result["reason"] = "2 of 3 conditions satisfied"

        elif result["score"] == 1:

            result["reason"] = "Only 1 condition satisfied"

        else:

            result["reason"] = "No conditions satisfied"

        return result

    def get_signal_count(self):

        return self.signal_count
