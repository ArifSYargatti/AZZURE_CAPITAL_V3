
from strategy import Strategy

strategy = Strategy()

result = strategy.check_entry(

    symbol="SBIN",

    nifty_price=23250,

    nifty_ema=23200,

    live_price=1002,

    ema5=998,

    ema15=997,

    stock_change=0.015,

    nifty_change=0.008,

    position_open=False

)

print()

print("Strategy Result:")

print(result)

print()

if result["signal"]:

    print("BUY SIGNAL GENERATED")

else:

    print("NO BUY SIGNAL")

    print(f"Reason : {result['reason']}")

print()

print(f"Total Signals : {strategy.get_signal_count()}")
