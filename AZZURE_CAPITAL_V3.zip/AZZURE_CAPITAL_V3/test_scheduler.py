
from scheduler import Scheduler

scheduler = Scheduler()

scheduler.status()

print()

print("Market Open :", scheduler.market_open())

print("Squareoff Due :", scheduler.squareoff_due())

print("Refresh Due :", scheduler.refresh_due())

print("Daily Reset Due :", scheduler.daily_reset_due())
