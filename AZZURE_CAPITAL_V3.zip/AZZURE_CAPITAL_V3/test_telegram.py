
from telegram_service import TelegramService

telegram = TelegramService()

telegram.engine_started()

telegram.login_success("RTR390")

telegram.buy_signal("SBIN", 1002.50)

telegram.target_hit("SBIN", 1250)

telegram.stoploss_hit("INFY", -450)

telegram.daily_summary(

    trades=8,

    wins=5,

    losses=3,

    pnl=3750

)
