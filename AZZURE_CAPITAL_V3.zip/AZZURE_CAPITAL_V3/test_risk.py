
from risk_manager import RiskManager

risk = RiskManager()

qty = risk.calculate_quantity(
    entry_price=1000,
    stop_loss=995
)

print(f"Calculated Qty : {qty}")

print(
    risk.can_take_trade(
        open_positions=0
    )
)

risk.update_trade_result(1500)

risk.update_trade_result(-500)

risk.print_summary()

