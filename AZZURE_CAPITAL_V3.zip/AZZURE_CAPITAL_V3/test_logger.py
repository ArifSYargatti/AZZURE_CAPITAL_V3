
from trade_logger import TradeLogger

logger = TradeLogger()

logger.log_trade(

    symbol="SBIN",

    action="BUY",

    entry_price=980,

    exit_price=990,

    quantity=100,

    pnl=1000,

    exit_reason="TARGET",

    ema20=975,

    atr14=8.5

)

