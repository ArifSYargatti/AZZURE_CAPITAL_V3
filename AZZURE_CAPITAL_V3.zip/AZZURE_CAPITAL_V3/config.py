"""
AZZURE CAPITAL V3
Professional Trading Engine Configuration
"""

# ======================================

# ENGINE

# ======================================

MODE = "PAPER"

# ======================================

# ZERODHA

# ======================================

API_KEY = "iplk77x2xiou9jdg"

API_SECRET = "ue5ljjxh1u1lwsinygq3jfxxxvrb03h8"

ACCESS_TOKEN = "kvrDx82uWuTMHVKaOv9CAMU8OvToAAR7"

# ======================================

# TELEGRAM

# ======================================

BOT_TOKEN = "8619360439:AAFOSwwpbWAP-AInfbnIjvuueOThQQsKChE"

CHAT_ID = "7304760370"

# ======================================

# CAPITAL

# ======================================

CAPITAL = 500000

RISK_PER_TRADE = 0.01

# ======================================

# RISK

# ======================================

MAX_OPEN_POSITIONS = 2

MAX_TRADES_PER_DAY = 10

MAX_CONSECUTIVE_LOSSES = 3

DAILY_LOSS_LIMIT = -5000

COOLDOWN_MINUTES = 15

# ======================================

# STRATEGY

# ======================================

EMA_PERIOD = 20

ATR_PERIOD = 14

TARGET_PERCENT = 1.0

STOPLOSS_PERCENT = 0.5

BREAK_EVEN_TRIGGER = 0.5

TRAILING_STOP_PERCENT = 0.3

# ======================================

# REFRESH

# ======================================

REFRESH_INTERVAL = 900

# ======================================

# AUTO SQUARE OFF

# ======================================

AUTO_SQUAREOFF_HOUR = 15

AUTO_SQUAREOFF_MINUTE = 20

# ======================================

# PATHS

# ======================================

CSV_LOG = "data/trade_log.csv"

SQLITE_DB = "data/trades.db"

LOG_FOLDER = "logs"

REPORT_FOLDER = "reports"
