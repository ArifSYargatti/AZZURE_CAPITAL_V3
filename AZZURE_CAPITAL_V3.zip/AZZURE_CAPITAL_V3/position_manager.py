
"""
position_manager.py

AZZURE CAPITAL V3
Professional Position Manager
"""


class PositionManager:

    def __init__(self):

        self.active_positions = {}

    def create_position(

        self,

        symbol,

        entry_price,

        quantity,

        stop_loss,

        target

    ):

        self.active_positions[symbol] = {

            "entry_price": entry_price,

            "quantity": quantity,

            "stop_loss": stop_loss,

            "target": target,

            "breakeven": False,

            "highest_price": entry_price

        }

        print(f"POSITION OPENED : {symbol}")

    def manage_position(

        self,

        symbol,

        live_price

    ):

        if symbol not in self.active_positions:

            return None

        position = self.active_positions[symbol]

        entry = position["entry_price"]

        target = position["target"]

        stop = position["stop_loss"]

        qty = position["quantity"]

        # Update highest price
        if live_price > position["highest_price"]:

            position["highest_price"] = live_price

        # Move to break-even
        if (

            not position["breakeven"]

            and

            live_price >= entry * 1.005

        ):

            position["stop_loss"] = entry

            position["breakeven"] = True

            print(f"{symbol} moved to BREAK-EVEN")

        # Trailing stop
        if position["breakeven"]:

            trailing_sl = position["highest_price"] * 0.997

            if trailing_sl > position["stop_loss"]:

                position["stop_loss"] = trailing_sl

        # Target hit
        if live_price >= target:

            pnl = round(

                (live_price - entry) * qty,

                2

            )

            return {

                "exit": True,

                "reason": "TARGET",

                "pnl": pnl

            }

        # Stop-loss hit
        if live_price <= position["stop_loss"]:

            pnl = round(

                (live_price - entry) * qty,

                2

            )

            return {

                "exit": True,

                "reason": "STOPLOSS",

                "pnl": pnl

            }

        return {

            "exit": False

        }

    def close_position(

        self,

        symbol

    ):

        if symbol in self.active_positions:

            del self.active_positions[symbol]

            print(f"POSITION CLOSED : {symbol}")

    def open_position_count(self):

        return len(self.active_positions)

