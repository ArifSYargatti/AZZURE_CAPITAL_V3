
from kiteconnect import KiteConnect
from config import API_KEY, ACCESS_TOKEN

kite = KiteConnect(api_key=API_KEY)
kite.set_access_token(ACCESS_TOKEN)

try:
    profile = kite.profile()

    print("LOGIN SUCCESS")

    print(profile)

except Exception as e:

    print("LOGIN FAILED")

    print(e)

