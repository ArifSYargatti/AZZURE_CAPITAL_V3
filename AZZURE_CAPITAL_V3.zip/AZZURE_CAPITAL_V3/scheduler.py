
"""
scheduler.py

AZZURE CAPITAL V3
Scheduler Module
"""

from datetime import datetime, time, timedelta

from config import (
    AUTO_SQUAREOFF_HOUR,
    AUTO_SQUAREOFF_MINUTE,
    REFRESH_INTERVAL
)


class Scheduler:

    def __init__(self):

        self.last_refresh = None

        self.last_reset_date = None

    def market_open(self):

        now = datetime.now().time()

        return time(9, 15) <= now <= time(15, 30)

    def squareoff_due(self):

        now = datetime.now().time()

        squareoff_time = time(
            AUTO_SQUAREOFF_HOUR,
            AUTO_SQUAREOFF_MINUTE
        )

        return now >= squareoff_time

    def refresh_due(self):

        if self.last_refresh is None:

            self.last_refresh = datetime.now()

            return False

        now = datetime.now()

        if now - self.last_refresh >= timedelta(seconds=REFRESH_INTERVAL):

            self.last_refresh = now

            return True

        return False

    def daily_reset_due(self):

        today = datetime.now().date()

        if self.last_reset_date != today:

            self.last_reset_date = today

            return True

        return False

    def cooldown_complete(self, last_exit_time, cooldown_minutes):

        if last_exit_time is None:

            return True

        return datetime.now() >= (
            last_exit_time + timedelta(minutes=cooldown_minutes)
        )

    def status(self):

        print("=" * 50)
        print("SCHEDULER STATUS")
        print(f"Market Open      : {self.market_open()}")
        print(f"Squareoff Due    : {self.squareoff_due()}")
        print(f"Refresh Due      : {self.refresh_due()}")
        print(f"Daily Reset Due  : {self.daily_reset_due()}")
        print("=" * 50)
