
"""
indicators.py

Technical Indicator Engine
"""

import ta


class IndicatorEngine:

    def add_indicators(self, df):

        df["EMA20"] = ta.trend.ema_indicator(
            df["close"],
            window=20
        )

        df["ATR14"] = ta.volatility.average_true_range(
            df["high"],
            df["low"],
            df["close"],
            window=14
        )

        return df

    def get_last_ema(self, df):

        return df["EMA20"].iloc[-1]

    def get_last_atr(self, df):

        return df["ATR14"].iloc[-1]

    def bullish(self, price, ema):

        return price > ema

    def relative_strength(
        self,
        stock_change,
        nifty_change
    ):

        return stock_change > nifty_change

