
from analytics import Analytics

analytics = Analytics()

analytics.summary()

analytics.symbol_performance()

analytics.max_drawdown()

analytics.equity_curve()

