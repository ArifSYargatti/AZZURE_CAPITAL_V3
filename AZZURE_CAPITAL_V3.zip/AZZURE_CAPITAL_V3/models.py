
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

@dataclass
class Position:

    symbol: str

    qty: int = 0

    entry_price: float = 0.0

    stop_loss: float = 0.0

    target: float = 0.0

    last_price: float = 0.0

    position: bool = False

    breakeven: bool = False

    trailing: bool = False

    entry_time: Optional[datetime] = None

    exit_time: Optional[datetime] = None

    last_exit_time: Optional[datetime] = None

