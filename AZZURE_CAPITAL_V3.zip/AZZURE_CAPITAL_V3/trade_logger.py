
"""
trade_logger.py

AZZURE CAPITAL V3
Professional Trade Logger

Logs trades to:
1. CSV
2. SQLite Database
"""

import os
import csv
import sqlite3
from datetime import datetime

from config import CSV_LOG, SQLITE_DB


class TradeLogger:

    def __init__(self):

        os.makedirs("data", exist_ok=True)

        self.initialize_csv()

        self.initialize_database()

    def initialize_csv(self):

        if os.path.exists(CSV_LOG):
            return

        with open(CSV_LOG, "w", newline="") as file:

            writer = csv.writer(file)

            writer.writerow([
                "Date",
                "Time",
                "Symbol",
                "Action",
                "EntryPrice",
                "ExitPrice",
                "Quantity",
                "PnL",
                "ExitReason",
                "EMA20",
                "ATR14"
            ])

    def initialize_database(self):

        conn = sqlite3.connect(SQLITE_DB)

        cursor = conn.cursor()

        cursor.execute("""

        CREATE TABLE IF NOT EXISTS trades(

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            trade_date TEXT,

            trade_time TEXT,

            symbol TEXT,

            action TEXT,

            entry_price REAL,

            exit_price REAL,

            quantity INTEGER,

            pnl REAL,

            exit_reason TEXT,

            ema20 REAL,

            atr14 REAL

        )

        """)

        conn.commit()

        conn.close()

    def log_trade(

        self,

        symbol,

        action,

        entry_price,

        exit_price,

        quantity,

        pnl,

        exit_reason,

        ema20=0,

        atr14=0

    ):

        now = datetime.now()

        trade_date = now.strftime("%Y-%m-%d")

        trade_time = now.strftime("%H:%M:%S")

        with open(CSV_LOG, "a", newline="") as file:

            writer = csv.writer(file)

            writer.writerow([

                trade_date,

                trade_time,

                symbol,

                action,

                entry_price,

                exit_price,

                quantity,

                pnl,

                exit_reason,

                ema20,

                atr14

            ])

        conn = sqlite3.connect(SQLITE_DB)

        cursor = conn.cursor()

        cursor.execute("""

        INSERT INTO trades(

            trade_date,

            trade_time,

            symbol,

            action,

            entry_price,

            exit_price,

            quantity,

            pnl,

            exit_reason,

            ema20,

            atr14

        )

        VALUES(?,?,?,?,?,?,?,?,?,?,?)

        """, (

            trade_date,

            trade_time,

            symbol,

            action,

            entry_price,

            exit_price,

            quantity,

            pnl,

            exit_reason,

            ema20,

            atr14

        ))

        conn.commit()

        conn.close()

        print("=" * 50)

        print(f"TRADE LOGGED : {symbol}")

        print(f"ACTION       : {action}")

        print(f"PNL          : {pnl}")

        print("=" * 50)

