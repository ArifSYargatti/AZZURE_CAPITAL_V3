
from position_manager import PositionManager

pm = PositionManager()

pm.create_position(

    symbol="SBIN",

    entry_price=1000,

    quantity=100,

    stop_loss=995,

    target=1010

)

prices = [

    1002,

    1004,

    1006,

    1008,

    1011

]

for price in prices:

    result = pm.manage_position(

        "SBIN",

        price

    )

    print(result)

    if result["exit"]:

        pm.close_position("SBIN")

        break

