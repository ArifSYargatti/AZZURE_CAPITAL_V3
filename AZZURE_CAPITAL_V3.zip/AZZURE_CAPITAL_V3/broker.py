
"""
broker.py

Handles Zerodha Login and WebSocket Connection
"""

from kiteconnect import KiteConnect, KiteTicker
from config import API_KEY, ACCESS_TOKEN


class Broker:

    def __init__(self):

        self.kite = KiteConnect(api_key=API_KEY)

        self.kite.set_access_token(ACCESS_TOKEN)

        self.kws = KiteTicker(API_KEY, ACCESS_TOKEN)

    def login(self):

        try:
            print(f"API_KEY      : {API_KEY}")
            print(f"ACCESS TOKEN : {ACCESS_TOKEN[:10]}...")
            
            profile = self.kite.profile()

            print("=" * 50)
            print("LOGIN SUCCESS")
            print(f"USER : {profile['user_id']}")
            print("=" * 50)

            return True

        except Exception as e:

            print("=" * 50)
            print("LOGIN FAILED")
            print(e)
            print("=" * 50)

            return False

    def get_profile(self):

        return self.kite.profile()

    def get_holdings(self):

        return self.kite.holdings()

    def get_positions(self):

        return self.kite.positions()

    def get_kite(self):

        return self.kite

    def get_socket(self):

        return self.kws

