
"""
analytics.py

AZZURE CAPITAL V3
Performance Analytics
"""

import os
import pandas as pd
import matplotlib.pyplot as plt

from config import CSV_LOG


class Analytics:

    def __init__(self):

        if os.path.exists(CSV_LOG):

            self.df = pd.read_csv(CSV_LOG)

        else:

            self.df = pd.DataFrame()

    def summary(self):

        if self.df.empty:

            print("No trades available.")

            return

        pnl = self.df["PnL"]

        total = len(self.df)

        wins = len(pnl[pnl > 0])

        losses = len(pnl[pnl <= 0])

        gross_profit = pnl[pnl > 0].sum()

        gross_loss = abs(pnl[pnl < 0].sum())

        net_pnl = pnl.sum()

        win_rate = round((wins / total) * 100, 2)

        profit_factor = round(

            gross_profit / gross_loss,

            2

        ) if gross_loss > 0 else 999

        avg_win = round(

            pnl[pnl > 0].mean(),

            2

        ) if wins > 0 else 0

        avg_loss = round(

            pnl[pnl < 0].mean(),

            2

        ) if losses > 0 else 0

        print("=" * 60)

        print("AZZURE CAPITAL V3 ANALYTICS")

        print("=" * 60)

        print(f"Total Trades     : {total}")

        print(f"Wins             : {wins}")

        print(f"Losses           : {losses}")

        print(f"Win Rate         : {win_rate}%")

        print(f"Net PnL          : ₹{net_pnl:.2f}")

        print(f"Gross Profit     : ₹{gross_profit:.2f}")

        print(f"Gross Loss       : ₹{gross_loss:.2f}")

        print(f"Profit Factor    : {profit_factor}")

        print(f"Average Winner   : ₹{avg_win}")

        print(f"Average Loser    : ₹{avg_loss}")

        print(f"Best Trade       : ₹{pnl.max()}")

        print(f"Worst Trade      : ₹{pnl.min()}")

        print("=" * 60)

    def equity_curve(self):

        if self.df.empty:

            return

        equity = self.df["PnL"].cumsum()

        plt.figure(figsize=(10, 5))

        plt.plot(equity)

        plt.title("Equity Curve")

        plt.xlabel("Trades")

        plt.ylabel("PnL")

        plt.grid(True)

        plt.show()

    def symbol_performance(self):

        if self.df.empty:

            return

        summary = self.df.groupby(

            "Symbol"

        )["PnL"].sum()

        print()

        print("Symbol Performance")

        print(summary)

    def max_drawdown(self):

        if self.df.empty:

            return

        equity = self.df["PnL"].cumsum()

        running_max = equity.cummax()

        drawdown = equity - running_max

        print()

        print(

            f"Maximum Drawdown : ₹{drawdown.min():.2f}"

        )
