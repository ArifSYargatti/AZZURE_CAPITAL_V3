
"""
dashboard.py

AZZURE CAPITAL V3
Professional Dashboard
"""

import os
import pandas as pd
import streamlit as st

from config import CSV_LOG

st.set_page_config(

    page_title="AZZURE CAPITAL V3",

    layout="wide"

)

st.title("🚀 AZZURE CAPITAL V3 Professional Dashboard")

st.markdown("---")

# -----------------------------
# Load Trade Log
# -----------------------------

if os.path.exists(CSV_LOG):

    df = pd.read_csv(CSV_LOG)

else:

    df = pd.DataFrame()

# -----------------------------
# Metrics
# -----------------------------

if len(df) > 0:

    total_trades = len(df)

    total_pnl = df["PnL"].sum()

    wins = len(df[df["PnL"] > 0])

    losses = len(df[df["PnL"] <= 0])

    win_rate = round(

        wins * 100 / total_trades,

        2

    )

else:

    total_trades = 0

    total_pnl = 0

    wins = 0

    losses = 0

    win_rate = 0

c1, c2, c3, c4 = st.columns(4)

c1.metric("Total Trades", total_trades)

c2.metric("Net PnL", f"₹ {total_pnl:.2f}")

c3.metric("Wins", wins)

c4.metric("Win Rate", f"{win_rate}%")

st.markdown("---")

# -----------------------------
# Recent Trades
# -----------------------------

st.subheader("Recent Trades")

if len(df) > 0:

    st.dataframe(

        df.tail(20),

        use_container_width=True

    )

else:

    st.info("No trades available.")

st.markdown("---")

# -----------------------------
# PnL Chart
# -----------------------------

if len(df) > 0:

    pnl_curve = df["PnL"].cumsum()

    st.subheader("Equity Curve")

    st.line_chart(pnl_curve)

st.markdown("---")

# -----------------------------
# Open Positions Placeholder
# -----------------------------

st.subheader("Open Positions")

st.info(

    "Live position integration will be added in the next milestone."

)

st.markdown("---")

# -----------------------------
# Auto Refresh
# -----------------------------

st.caption("Refresh the page to view the latest trade data.")
