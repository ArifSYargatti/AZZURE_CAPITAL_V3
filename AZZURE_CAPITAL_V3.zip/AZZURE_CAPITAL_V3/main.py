
"""
AZZURE CAPITAL V3
Professional Trading Engine
"""

from data_loader import DataLoader
from broker import Broker
from config import MODE
from models import Position
from indicators import IndicatorEngine

class TradingEngine:

    def load_initial_data(self):

        print()

        print("Loading historical data...")

        # Example token for NIFTY 50 Index
        nifty_token = 256265

        nifty_df = self.data_loader.get_nifty_data(
             nifty_token
        )
        
        nifty_df = self.indicators.add_indicators(nifty_df)

        print(
            f"NIFTY EMA20 :  {self.indicators.get_last_ema(nifty_df):.2f}"
        )

        print(
            f"NIFTY ATR14 : {self.indicators.get_last_atr(nifty_df):.2f}"
        )
        
        print(
            f"NIFTY rows loaded : {len(nifty_df)}"
        )

    def __init__(self):

        self.broker = Broker()

        self.positions = {}

        self.total_pnl = 0

        self.trade_count = 0

        self.data_loader = DataLoader(
            self.broker.get_kite()
        )
        
        self.indicators = IndicatorEngine()

    def display_status(self):

        print("=" * 50)
        print("        AZZURE CAPITAL V3")
        print("=" * 50)
        print(f"MODE           : {MODE}")
        print(f"OPEN POSITIONS : {len(self.positions)}")
        print(f"TOTAL PNL      : {self.total_pnl}")
        print(f"TRADE COUNT    : {self.trade_count}")
        print("=" * 50)

    def start(self):

        self.display_status()

        print()

        print("Connecting to Zerodha...")

        success = self.broker.login()

        if success:

            print()

            print("Broker Connected Successfully")

            self.load_initial_data()

        else:

            print()

            print("Unable to Connect Broker")


if __name__ == "__main__":

    engine = TradingEngine()

    engine.start()
